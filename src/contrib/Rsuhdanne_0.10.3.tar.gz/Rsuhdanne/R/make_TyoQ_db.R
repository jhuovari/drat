#' Read Tyovoimatiedustelun maakuntatauluja and write to rds-file
#'
#'
#' Read "Maakunta1" and "Maakunta2" px-files and write to rds file.
#' Add It�-Uusimaa to Uusimaa if prensent.
#' writes variables "Ty�ik�inen v�est�", "Ty�lliset", "Ty�tt�m�t", "Ty�voima", "Ty�voimaan kuulumattomat" for Maakunta1.
#' Ratios are omit because aggregating Uusimaa and Ita-Uusimaa.
#' Calls \code{\link{read_tyoQ}}
#' 
#' 
#' @param to_file A path to file to write. If \code{NULL} just returns a data.frame (invisibly)
#' 
#' @return (invisibly) a data.frame and write to rds-file, if given
#'
#' @family tyoQ
#' @export
#' @keywords IO
#' @examples 
#'   \dontrun{
#' k <- make_TyoQ_1_rds(file.path(tietok_dir(), "SarjatTK/Tyo_Q_1.rds"))
#' k <- make_TyoQ_2_rds(file.path(tietok_dir(), "SarjatTK/Tyo_Q_2.rds"))
#' }
make_TyoQ_1_rds <- function(to_file = NULL){
    
  # Luettavat tiedostot 1
  files1 <- tyoQfiles("aakunta1")
  
  # read px-files
  dat_px <- lapply(files1, function(x) dloads::read.px(x, org.order = FALSE))
  
  ## clean data
  # names
  dat0 <- lapply(dat_px, function(x){
    nn <- names(x)
    nn[grep("aakunta", nn)] <- "Maakunta"
    nn[grep("Ik�", nn)] <- "Ika"
    names(x) <- nn
    x
  })
  
  # to data.frame
  dat1 <- do.call(rbind, dat0)
  
  # only last observations
  dat1 <- distinct(dat1[nrow(dat1):1L,], Maakunta, Ajanjakso, Vuosi, Ika, Tiedot, Sukupuoli, .keep_all = TRUE)
  dat1 <- dat1[nrow(dat1):1L,]

  # Unify naming
  dat1$Tiedot <- mapvalues(dat1$Tiedot, "Ty�voimaan kuulumattomat yhteens�", "Ty�voimaan kuulumattomat")  
  
  # Ita-Uusimaa to uusimaa
  dat1 <- filter(dat1, !(Maakunta == "It�-Uusimaa" & Vuosi == "2010"))   # I-Uusimaa is already in Uusimaa in most resent 2010 data
  dat1$Maakunta <- mapvalues(dat1$Maakunta, "It�-Uusimaa", "Uusimaa")

  
  dat2 <- dat1 %>%
    filter(Maakunta != " ",
           Tiedot %in% c("Ty�ik�inen v�est�", "Ty�lliset", "Ty�tt�m�t", "Ty�voima", "Ty�voimaan kuulumattomat"))  %>%            # Tyhj� maakunta pois
    distinct() %>%
    group_by(Maakunta, Ajanjakso, Vuosi, Ika, Tiedot, Sukupuoli) %>%
    summarise(data = sum(data, na.rm = TRUE)) %>%
    ungroup() %>%
    droplevels()
  
  if (!is.null(to_file)) saveRDS(dat2, file = to_file)
  
  invisible(dat2)
  
} 

#' @rdname make_TyoQ_1_rds
#' @export
make_TyoQ_2_rds <- function(to_file = NULL){
  
  # Luettavat tiedostot 1
  files1 <- tyoQfiles("aakunta2")[-1] # ensimmaisessa vanha toimialajako, ei kayteta
  
  # read px-files
  dat_px <- lapply(files1, function(x) dloads::read.px(x, org.order = FALSE))
  
  ## clean data
  # names
  dat0 <- lapply(dat_px, function(x){
    nn <- names(x)
    nn[grep("aakunta", nn)] <- "Maakunta"
    nn[grep("TOL", nn)] <- "tol"
    names(x) <- nn
    x
  })
  
  # to data.frame
  dat1 <- do.call(rbind, dat0)
  
  # only last observations
  dat1 <- distinct(dat1[nrow(dat1):1L,], Maakunta, Ajanjakso, Vuosi, tol, Tiedot, .keep_all = TRUE)
  dat1 <- dat1[nrow(dat1):1L,]
  
  # Unify tol
  
  TOL1 = c("A, B  Maatalous, mets�talous, kalatalous; kaivostoiminta (01-09)",                    
           "C-E  Teollisuus; s�hk�-, l�mp�-, vesi- ja j�tehuolto yms. (10-39)",                   
           "F  Rakentaminen (41-43)",                                                             
           "G  Tukku- ja v�hitt�iskauppa; moottoriajoneuvojen ja moottoripy�rien korjaus (45-47)",
           "H   Kuljetus ja varastointi (49-53)",                                                 
           "I   Majoitus- ja ravitsemistoiminta (55-56)",                                         
           "J   Informaatio ja viestint� (58-63)",                                                
           "K, L  Rahoitus- ja vakuutustoiminta; kiinteist�ala (64-68)",                          
           "M, N  Liike-el�m�n palvelut (69-82)",                                                 
           "O   Julkinen hallinto ja maanpuolustus; pakollinen sosiaalivakuutus (84)",            
           "P   Koulutus (85)",                                                                   
           "Q   Terveys- ja sosiaalipalvelut (86-88)",                                            
           "R-U  Muu palvelutoiminta (90-99)",                                                    
           "Toimialat yhteens� (00-99)"                                                          
  )
  TOL2 = c("A, B   Maa-, mets�- ja kalatalous; kaivostoiminta (01-09)",                            
           "C-E   Teollisuus; s�hk�-, l�mp�-, vesi- ja j�tehuolto yms. (10-39)",                   
           "F   Rakentaminen (41-43)",                                                             
           "G   Tukku- ja v�hitt�iskauppa; moottoriajoneuvojen ja moottoripy�rien korjaus (45-47)",
           "H   Kuljetus ja varastointi (49-53)",                                                  
           "I   Majoitus- ja ravitsemistoiminta (55-56)",                                          
           "J   Informaatio ja viestint� (58-63)",                                                 
           "K, L   Rahoitus- ja vakuutustoiminta; kiinteist�ala (64-68)",                          
           "M, N   Liike-el�m�n palvelut (69-82)",                                                 
           "O   Julkinen hallinto ja maanpuolustus; pakollinen sosiaalivakuutus (84)",             
           "P   Koulutus (85)",                                                                    
           "Q   Terveys- ja sosiaalipalvelut (86-88)",                                             
           "R-U   Muu palvelutoiminta (90-99)",                                                    
           "Toimialat yhteens� (00-99)"                                                           
  )
  
  TOL3 = c("A, B   Maatalous, mets�talous, kalatalous; kaivostoiminta (01-09)",                    
           "C-E   Teollisuus; s�hk�-, l�mp�-, vesi- ja j�tehuolto yms. (10-39)",
           "F   Rakentaminen (41-43)",
           "G   Tukku- ja v�hitt�iskauppa; moottoriajoneuvojen ja moottoripy�rien korjaus (45-47)",
           "H   Kuljetus ja varastointi (49-53)",
           "I   Majoitus- ja ravitsemistoiminta (55-56)",
           "J   Informaatio ja viestint� (58-63)",
           "K, L   Rahoitus- ja vakuutustoiminta; kiinteist�ala (64-68)",
           "M, N   Liike-el�m�n palvelut (69-82)",                              
           "O   Julkinen hallinto ja maanpuolustus; pakollinen sosiaalivakuutus (84)",
           "P   Koulutus (85)",
           "Q   Terveys- ja sosiaalipalvelut (86-88)",
           "R-U   Muu palvelutoiminta (90-99)",
           "Toimialat yhteens� (00-99)"
  )
  
  
  dat1$tol <- plyr::mapvalues(dat1$tol, TOL2, TOL3)
  dat1$tol <- plyr::mapvalues(dat1$tol, TOL1, TOL3)
  
  # Ita-Uusimaa to uusimaa
  dat1 <- filter(dat1, !(Maakunta == "It�-Uusimaa" & Vuosi == "2010"))   # I-Uusimaa is already in Uusimaa in most resent 2010 data
  dat1$Maakunta <- mapvalues(dat1$Maakunta, "It�-Uusimaa", "Uusimaa")
  
  
  dat2 <- dat1 %>%
    filter(Maakunta != " ",
           tol != " ")  %>%         # Tyhj� maakunta ja tol pois
    distinct() %>%
    group_by(Maakunta, Ajanjakso, Vuosi, tol, Tiedot) %>%
    summarise(data = sum(data, na.rm = TRUE)) %>%
    ungroup() %>%
    droplevels()
  
  if (!is.null(to_file)) saveRDS(dat2, file = to_file)
  
  invisible(dat2)
  
} 
