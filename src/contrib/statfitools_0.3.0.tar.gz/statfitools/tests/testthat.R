library(testthat)
library(statfitools)

test_check("statfitools")
