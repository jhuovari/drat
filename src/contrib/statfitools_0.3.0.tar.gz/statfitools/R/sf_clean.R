#' Makes basic cleaning for StatFin data
