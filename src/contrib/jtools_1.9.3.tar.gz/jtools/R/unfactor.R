#' Factor to numeric or character vector
#' 
#' Functions to convert factors to numeric or character vector.
#' \code{unfactor} for both conversions and \code{factor.no} of only for
#' numeric converstion
#' 
#' \code{unfactor} is used to convert \code{\link{factor}}s with numeric or
#' character levels to numeric of character vector based on leves. Without type
#' specified \code{unfactor} first tries to convert to numeric and if not
#' possible to characters.  \code{factor.no} converts only numeric levels to
#' numeric vector.
#' 
#' @aliases unfactor factor.no
#' @param f A factor to convert
#' @param type 1-character string giving the type of vector desired or NULL.
#' Possible values "c" for character and "n" for numeric.  NULL gives numeric
#' if possible and otherwise character.
#' @export
#' @return A numeric or character vector with same length as \code{f}
#' @author Janne Huovari
#' @references
#' \url{http://rwiki.sciviews.org/doku.php?id=tips:data-factors:factors}
#' @keywords manip factor numeric
#' @examples
#' 
#' f <- factor(c(1,1,2,3,3))
#' unfactor(f)
#' factor.no(f)
#' 
unfactor <-
function(f, type = NULL) {
                  if (!is.factor(f)) stop("Error: input is not factor")
                  if (is.null(type)) {  
                      num <- suppressWarnings(as.numeric(levels(f)))
                      if (any(is.na(num))) return(levels(f)[f])
                      else return(num[f])
                  }
                  if (type == "n") return(as.numeric(levels(f))[f])
                  if (type == "c") return(levels(f)[f])
                  else stop("Error wrong type")   
}

