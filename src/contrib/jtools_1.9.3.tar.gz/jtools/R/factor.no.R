#' @rdname unfactor
#' @export
factor.no <- function(f) as.numeric(levels(f))[f]

