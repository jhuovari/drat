#' The directory path for Projektit
#'
#' The directory path for Projektit
#' @name constants
#' @aliases constants projektit
#' @keywords IO
#' @export projektit
projektit <- function() "Y:/Projektit KT"

