#' Class \code{"f.orgorder"} for \code{read.table} functions to create factors
#' with original order
#' 
#' Factor class that preserves original order of levels. Usually used as
#' \code{colClasses} argument for \code{\link{read.table}} functions.
#' @name f.orgorder-class
#' @aliases f.orgorder-class coerce,character,f.orgorder-method
#' @docType class
#' @export
#' @author Janne Huovari
#' @keywords classes
#' @examples
#' 
#' showClass("f.orgorder")
#' 
#' z <- c("c", "b", "a")
#' x <- data.frame(normal = z, orgorder = z)
#' tf <- tempfile(fileext = ".csv")
#' write.csv(x, file = tf, row.names = FALSE)
#' y <- read.csv(tf, colClasses = c("factor", "f.orgorder"))
#' print(lapply(y, levels))
#' unlink(tf)
#' 
#'
setClass("f.orgorder")
setAs("character", "f.orgorder", function(from) factor(from, levels = unique(from)))

#' Modification of the \code{\link{factor}} to order levels in original order
#' 
#' @param x a vector of data
#' @param ... other parameters, passed to the \code{\link{factor}}.
#' @export
factor_org <- function(x, ...){
  y <- factor(x, levels = unique(x), ...)
  y
}
