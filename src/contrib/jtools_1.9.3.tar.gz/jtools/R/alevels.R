#' List of levels of all factors in object
#' 
#' Work at least for data.frames
#'
#' @param x an object
#' @export
#' @return Namede list of factory levels.
#' @keywords utilities
alevels <- function(x){
  y <- lapply(x[sapply(x, is.factor)], levels)
  y
}
