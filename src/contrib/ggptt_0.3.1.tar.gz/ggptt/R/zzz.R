# .onLoad <- function(libname, pkgname) {
#   theme_set(theme_ptt())
#   packageStartupMessage("theme_ptt set for ggplot2")
#   invisible()
# }
