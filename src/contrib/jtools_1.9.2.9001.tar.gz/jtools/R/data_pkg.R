#' List datasets for package
#' 
#' @param pkg A character vector giving the package(s) to look in for data sets.
#'   "." (the default) uses package of current directory, if possible to coerce
#'   to a package by \code{\link[devtools]{as.package}}.
#' 
#' @export
#'
#' @examples 
#'  data_pkg("datasets")
#'  \dontrun{
#'   data_pkg()
#'   }
#'   
data_pkg <- function(pkg = "."){
  if (file.exists(pkg)) {
    pkg <- devtools::as.package(pkg)$package
  }
  data(package = pkg)
}
