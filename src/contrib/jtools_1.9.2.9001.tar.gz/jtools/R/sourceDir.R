#' source() files in directory
#' 
#' Pass all R files in the \code{path} to \code{\link{source}}.
#' 
#' Pass all R files in the \code{path} to \code{\link{source}}.
#' 
#' @param path a character string giving the pathname of the files.
#' @param trace logical; if \code{TRUE}, print files
#' @param ... Other argument to \code{\link{source}}
#' @export
#' @seealso \code{\link{source}}
#' @references \code{\link{source}}
#' @keywords manip utilities numeric
sourceDir <- function(path, trace = TRUE, ...) {
    for (nm in list.files(path, pattern = "\\.[RrSsQq]$")) {
       if(trace) cat(nm,":")           
       source(file.path(path, nm), ...)
       if(trace) cat("\n")
    }
}
