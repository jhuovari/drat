library(testthat)
library(macrobonder)

test_check("macrobonder")
