library(testthat)
library(ggptt)

test_check("ggptt")
